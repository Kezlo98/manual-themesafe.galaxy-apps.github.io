// Small utilities shared by theme widgets
window.ThemeUtil = {
  later: function (fnName, ms) {
    setTimeout(fnName + '()', ms);
  }
};
// Embedded review widget talks to us through postMessage
window.addEventListener('message', function (event) {
  var data = event.data || {};
  if (data.type === 'review-html') {
    document.getElementById('reviews').innerHTML = data.html;
  }
});
